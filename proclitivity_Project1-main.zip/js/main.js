function OpenNav(){
    document.getElementById('mysidenav').style.width = '250px';
}

function CloseNav(){
    document.getElementById('mysidenav').style.width = '0';
}